"use client";
import { useState, useMemo } from "react";
import { T, cardStyle, type Route } from "@/data/tokens";
import { IcCheck, IcArrow } from "./icons";

type Props = { onNavigate: (r: Route) => void };

const MONTHS = ["januari", "februari", "maart", "april", "mei", "juni", "juli", "augustus", "september", "oktober", "november", "december"];
const DAYS = ["Ma", "Di", "Wo", "Do", "Vr", "Za", "Zo"];

function toKey(d: Date) { return d.toISOString().split("T")[0]; }
function fromKey(s: string) { return new Date(s + "T12:00:00"); }

export function Terugkomen({ onNavigate }: Props) {
  const [step, setStep] = useState(1);
  const [fromDate, setFromDate] = useState<string | null>(null);
  const [toDate, setToDate] = useState<string | null>(null);
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [persons, setPersons] = useState(2);
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [calMonth, setCalMonth] = useState(() => {
    const n = new Date();
    return { year: n.getFullYear(), month: n.getMonth() };
  });

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  /* ═══ CALENDAR LOGIC ═══ */
  const calDays = useMemo(() => {
    const first = new Date(calMonth.year, calMonth.month, 1);
    const startDay = (first.getDay() + 6) % 7; // Monday = 0
    const daysInMonth = new Date(calMonth.year, calMonth.month + 1, 0).getDate();
    const cells: (Date | null)[] = [];
    for (let i = 0; i < startDay; i++) cells.push(null);
    for (let i = 1; i <= daysInMonth; i++) cells.push(new Date(calMonth.year, calMonth.month, i));
    return cells;
  }, [calMonth]);

  const handleDateClick = (d: Date) => {
    if (d < today) return;
    const key = toKey(d);
    if (!fromDate || (fromDate && toDate)) {
      setFromDate(key);
      setToDate(null);
    } else {
      if (d < fromKey(fromDate)) {
        setFromDate(key);
      } else {
        const nights = Math.round((d.getTime() - fromKey(fromDate).getTime()) / (1000 * 60 * 60 * 24));
        if (nights < 2) return; // minimum 2 nights
        setToDate(key);
      }
    }
  };

  const isInRange = (d: Date) => {
    if (!fromDate || !toDate) return false;
    return d >= fromKey(fromDate) && d <= fromKey(toDate);
  };

  const isFrom = (d: Date) => fromDate === toKey(d);
  const isTo = (d: Date) => toDate === toKey(d);
  const isPast = (d: Date) => d < today;

  const nights = fromDate && toDate
    ? Math.round((fromKey(toDate).getTime() - fromKey(fromDate).getTime()) / (1000 * 60 * 60 * 24))
    : 0;

  const formatDate = (key: string) => {
    const d = fromKey(key);
    return d.toLocaleDateString("nl-NL", { day: "numeric", month: "long" });
  };

  const prevMonth = () => setCalMonth(p => p.month === 0 ? { year: p.year - 1, month: 11 } : { year: p.year, month: p.month - 1 });
  const nextMonth = () => setCalMonth(p => p.month === 11 ? { year: p.year + 1, month: 0 } : { year: p.year, month: p.month + 1 });

  /* ═══ SUBMIT ═══ */
  const canSubmit = fromDate && toDate && email.includes("@") && !loading;

  const submit = async () => {
    if (!canSubmit) return;
    setLoading(true);
    try {
      await fetch("/api/terugkomen", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          from: formatDate(fromDate!),
          to: formatDate(toDate!),
          email, name, persons, message,
        }),
      });
    } catch {}
    setLoading(false);
    setSuccess(true);
  };

  /* ═══ SUCCESS STATE ═══ */
  if (success) {
    return (
      <div style={{ padding: "0 24px 110px" }}>
        <div style={{ paddingTop: 60, textAlign: "center", animation: "fadeUp .5s ease both" }}>
          <div style={{ fontSize: 48, marginBottom: 20 }}>🌿</div>
          <h1 style={{ fontFamily: T.serif, fontSize: 28, fontWeight: 700, color: T.text, margin: "0 0 10px" }}>
            Dank je wel
          </h1>
          <p style={{ fontFamily: T.sans, fontSize: 15, color: T.muted, fontWeight: 300, lineHeight: 1.6, margin: "0 0 28px", maxWidth: 300, marginLeft: "auto", marginRight: "auto" }}>
            We gaan een mooi voorstel voor je samenstellen. Je ontvangt binnen 24 uur een persoonlijk aanbod.
          </p>

          <div style={{ ...cardStyle, padding: "18px 20px", textAlign: "left", marginBottom: 24 }}>
            {["Beste prijs garantie", "Speciaal voor terugkerende gasten", "Geen verplichting"].map((t, i) => (
              <div key={i} style={{
                display: "flex", alignItems: "center", gap: 10, padding: "8px 0",
                borderBottom: i < 2 ? `1px solid ${T.border}` : "none",
              }}>
                <span style={{ color: T.green }}><IcCheck /></span>
                <span style={{ fontFamily: T.sans, fontSize: 14, color: T.text, fontWeight: 300 }}>{t}</span>
              </div>
            ))}
          </div>

          <button onClick={() => onNavigate("home")} style={{
            padding: "14px 32px", borderRadius: 14, border: "none",
            background: T.green, color: "#fff",
            fontFamily: T.sans, fontSize: 15, fontWeight: 500, cursor: "pointer",
          }}>
            Terug naar overzicht
          </button>
        </div>
      </div>
    );
  }

  /* ═══ MAIN FLOW ═══ */
  return (
    <div style={{ padding: "0 20px 110px" }}>
      {/* Header */}
      <div style={{ paddingTop: 28 }}>
        <button onClick={() => onNavigate("info")} style={{
          background: "none", border: "none", cursor: "pointer", color: T.muted,
          fontFamily: T.sans, fontSize: 13, fontWeight: 300, padding: 0, marginBottom: 12,
          display: "flex", alignItems: "center", gap: 4,
        }}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round"><line x1="19" y1="12" x2="5" y2="12" /><polyline points="12 19 5 12 12 5" /></svg>
          Terug
        </button>
        <h1 style={{ fontFamily: T.serif, fontSize: 28, fontWeight: 700, color: T.text, margin: "0 0 6px" }}>
          Kom nog eens terug
        </h1>
        <p style={{ fontFamily: T.sans, fontSize: 14, color: T.muted, fontWeight: 300, margin: "0 0 20px", lineHeight: 1.5 }}>
          Kies je gewenste periode en ontvang een persoonlijk aanbod met beste prijs garantie
        </p>
      </div>

      {/* Trust badges */}
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 24 }}>
        {["Altijd scherper dan booking sites", "Persoonlijk afgestemd", "Geen verplichting"].map((t, i) => (
          <div key={i} style={{
            display: "flex", alignItems: "center", gap: 5,
            fontFamily: T.sans, fontSize: 11, color: T.green, fontWeight: 400,
          }}>
            <span style={{ color: T.green, fontSize: 12 }}>✓</span> {t}
          </div>
        ))}
      </div>

      {/* Step indicator */}
      <div style={{ display: "flex", gap: 8, marginBottom: 20 }}>
        {[1, 2].map(s => (
          <div key={s} style={{
            flex: 1, height: 3, borderRadius: 2,
            background: step >= s ? T.green : T.border,
            transition: "background .3s ease",
          }} />
        ))}
      </div>
      <div style={{ fontFamily: T.sans, fontSize: 11, color: T.muted, fontWeight: 300, marginBottom: 16 }}>
        Stap {step} van 2 — {step === 1 ? "Kies je periode" : "Je gegevens"}
      </div>

      {/* STEP 1: Calendar */}
      {step === 1 && (
        <div style={{ animation: "fadeUp .3s ease both" }}>
          <div style={{ ...cardStyle, padding: "20px 16px" }}>
            {/* Month nav */}
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
              <button onClick={prevMonth} style={{ background: "none", border: "none", cursor: "pointer", color: T.muted, padding: 4 }}>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round"><polyline points="15 18 9 12 15 6" /></svg>
              </button>
              <div style={{ fontFamily: T.serif, fontSize: 17, fontWeight: 600, color: T.text }}>
                {MONTHS[calMonth.month]} {calMonth.year}
              </div>
              <button onClick={nextMonth} style={{ background: "none", border: "none", cursor: "pointer", color: T.muted, padding: 4 }}>
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round"><polyline points="9 18 15 12 9 6" /></svg>
              </button>
            </div>

            {/* Day headers */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)", gap: 2, marginBottom: 4 }}>
              {DAYS.map(d => (
                <div key={d} style={{
                  textAlign: "center", fontFamily: T.sans, fontSize: 11,
                  color: T.muted, fontWeight: 500, padding: "4px 0",
                }}>
                  {d}
                </div>
              ))}
            </div>

            {/* Days grid */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)", gap: 2 }}>
              {calDays.map((d, i) => {
                if (!d) return <div key={i} />;
                const past = isPast(d);
                const from = isFrom(d);
                const to = isTo(d);
                const inR = isInRange(d);
                const selected = from || to;

                return (
                  <button
                    key={i}
                    onClick={() => !past && handleDateClick(d)}
                    disabled={past}
                    style={{
                      width: "100%", aspectRatio: "1", borderRadius: selected ? 10 : inR ? 0 : 10,
                      border: "none", cursor: past ? "default" : "pointer",
                      fontFamily: T.sans, fontSize: 14, fontWeight: selected ? 600 : 300,
                      background: selected ? T.green : inR ? "rgba(47,79,62,.08)" : "transparent",
                      color: past ? T.border : selected ? "#fff" : T.text,
                      transition: "all .1s ease",
                      WebkitTapHighlightColor: "transparent",
                    }}
                  >
                    {d.getDate()}
                  </button>
                );
              })}
            </div>

            {/* Min nights notice */}
            <div style={{ fontFamily: T.sans, fontSize: 11, color: T.muted, fontWeight: 300, marginTop: 12, textAlign: "center" }}>
              {fromDate && !toDate ? "Selecteer een einddatum (min. 2 nachten)" : "Minimaal 2 nachten"}
            </div>
          </div>

          {/* Selection summary */}
          {fromDate && toDate && (
            <div style={{
              marginTop: 14, padding: "14px 18px", borderRadius: 14,
              background: "rgba(47,79,62,.06)", border: `1px solid rgba(47,79,62,.15)`,
              display: "flex", justifyContent: "space-between", alignItems: "center",
              animation: "fadeUp .25s ease both",
            }}>
              <div>
                <div style={{ fontFamily: T.sans, fontSize: 13, color: T.text, fontWeight: 400 }}>
                  {formatDate(fromDate)} — {formatDate(toDate)}
                </div>
                <div style={{ fontFamily: T.sans, fontSize: 12, color: T.green, fontWeight: 500 }}>
                  {nights} nachten
                </div>
              </div>
            </div>
          )}

          {/* Next button */}
          <button
            onClick={() => fromDate && toDate && setStep(2)}
            disabled={!fromDate || !toDate}
            style={{
              width: "100%", padding: 16, borderRadius: 16, border: "none",
              background: fromDate && toDate ? T.green : T.border,
              color: "#fff", fontFamily: T.sans, fontSize: 16, fontWeight: 500,
              cursor: fromDate && toDate ? "pointer" : "not-allowed",
              marginTop: 20,
              display: "flex", alignItems: "center", justifyContent: "center", gap: 8,
            }}
          >
            Volgende stap <IcArrow />
          </button>
        </div>
      )}

      {/* STEP 2: Form */}
      {step === 2 && (
        <div style={{ animation: "fadeUp .3s ease both" }}>
          {/* Period summary */}
          <div style={{
            ...cardStyle, padding: "16px 18px", marginBottom: 20,
            display: "flex", justifyContent: "space-between", alignItems: "center",
          }}>
            <div>
              <div style={{ fontFamily: T.sans, fontSize: 13, color: T.text }}>
                {formatDate(fromDate!)} — {formatDate(toDate!)}
              </div>
              <div style={{ fontFamily: T.sans, fontSize: 12, color: T.green, fontWeight: 500 }}>{nights} nachten</div>
            </div>
            <button onClick={() => setStep(1)} style={{
              background: "none", border: "none", cursor: "pointer",
              fontFamily: T.sans, fontSize: 12, color: T.gold, fontWeight: 400,
            }}>Wijzig</button>
          </div>

          {/* Form */}
          <div style={{ ...cardStyle, padding: "22px 20px" }}>
            {/* Email */}
            <div style={{ marginBottom: 14 }}>
              <div style={{ fontFamily: T.sans, fontSize: 12, color: T.muted, marginBottom: 6, fontWeight: 300 }}>E-mailadres *</div>
              <input value={email} onChange={e => setEmail(e.target.value)} placeholder="jouw@email.nl" type="email"
                style={{ width: "100%", padding: "12px 14px", borderRadius: 12, border: `1px solid ${T.border}`, background: T.card, fontFamily: T.sans, fontSize: 16, color: T.text, fontWeight: 300, outline: "none" }} />
            </div>

            {/* Name */}
            <div style={{ marginBottom: 14 }}>
              <div style={{ fontFamily: T.sans, fontSize: 12, color: T.muted, marginBottom: 6, fontWeight: 300 }}>
                Naam <span style={{ opacity: 0.5 }}>(optioneel)</span>
              </div>
              <input value={name} onChange={e => setName(e.target.value)} placeholder="Hoe mogen we je noemen?"
                style={{ width: "100%", padding: "12px 14px", borderRadius: 12, border: `1px solid ${T.border}`, background: T.card, fontFamily: T.sans, fontSize: 16, color: T.text, fontWeight: 300, outline: "none" }} />
            </div>

            {/* Persons */}
            <div style={{ marginBottom: 14 }}>
              <div style={{ fontFamily: T.sans, fontSize: 12, color: T.muted, marginBottom: 6, fontWeight: 300 }}>Aantal personen</div>
              <div style={{ display: "flex", gap: 8 }}>
                {[1, 2, 3, 4, 5, 6].map(n => (
                  <button key={n} onClick={() => setPersons(n)} style={{
                    flex: 1, padding: "10px 0", borderRadius: 10, fontFamily: T.sans, fontSize: 14,
                    fontWeight: persons === n ? 600 : 300,
                    background: persons === n ? T.green : T.card,
                    color: persons === n ? "#fff" : T.text,
                    border: persons === n ? "none" : `1px solid ${T.border}`,
                    cursor: "pointer",
                  }}>{n}</button>
                ))}
              </div>
            </div>

            {/* Message */}
            <div style={{ marginBottom: 4 }}>
              <div style={{ fontFamily: T.sans, fontSize: 12, color: T.muted, marginBottom: 6, fontWeight: 300 }}>
                Opmerking <span style={{ opacity: 0.5 }}>(optioneel)</span>
              </div>
              <textarea value={message} onChange={e => setMessage(e.target.value)} placeholder="Bijv. verjaardagsweekend, met hond, etc."
                rows={2} style={{ width: "100%", padding: "12px 14px", borderRadius: 12, border: `1px solid ${T.border}`, background: T.card, fontFamily: T.sans, fontSize: 14, color: T.text, fontWeight: 300, outline: "none", resize: "none", lineHeight: 1.5 }} />
            </div>
          </div>

          {/* CTA */}
          <button onClick={submit} disabled={!canSubmit} style={{
            width: "100%", padding: 16, borderRadius: 16, border: "none",
            background: canSubmit ? `linear-gradient(135deg, ${T.green} 0%, ${T.green2} 100%)` : T.border,
            color: "#fff", fontFamily: T.serif, fontSize: 17, fontWeight: 600,
            cursor: canSubmit ? "pointer" : "not-allowed",
            marginTop: 20,
            boxShadow: canSubmit ? "0 8px 32px rgba(47,79,62,.25)" : "none",
          }}>
            {loading ? "Even geduld..." : "Ontvang mijn persoonlijke aanbod"}
          </button>

          {/* Trust */}
          <div style={{ textAlign: "center", marginTop: 12 }}>
            <div style={{ fontFamily: T.sans, fontSize: 11, color: T.muted, fontWeight: 300 }}>
              Wij reageren meestal binnen enkele uren
            </div>
            <div style={{ fontFamily: T.sans, fontSize: 10, color: T.border, fontWeight: 300, marginTop: 4 }}>
              Geen spam. Alleen een persoonlijk aanbod.
            </div>
          </div>

          {/* Back */}
          <button onClick={() => setStep(1)} style={{
            width: "100%", marginTop: 12, background: "none", border: "none",
            fontFamily: T.sans, fontSize: 13, color: T.muted, fontWeight: 300,
            cursor: "pointer", padding: 8,
          }}>
            ← Terug naar kalender
          </button>
        </div>
      )}
    </div>
  );
}
